var piechart,bartodaychart,linechart,bartotalchart;

var piedata = {
	'xdata':['失信被执行人','最高法被执行人','催欠公告','网贷逾期信息','信贷中介查询信息','网络负面信息','不良信息'],
	'ydata':[
	            {value:335, name:'失信被执行人'},
	            {value:310, name:'最高法被执行人'},
	            {value:234, name:'催欠公告'},
	            {value:135, name:'网贷逾期信息'},
	            {value:1548, name:'信贷中介查询信息'},
	            {value:548, name:'网络负面信息'},
	            {value:148, name:'不良信息'}
		    ]
};

var bartodaydata={
	'xdata':['失信被执行人','最高法被执行人','催欠公告','网贷逾期信息','信贷中介查询信息','网络负面信息','不良信息'],
	'ydata1':[11, 11, 15, 13, 12, 13, 10],
	'ydata2':[15, 13, 12, 13, 10,11, 11]
};

var linedata = {
	'xdata1':['星期一','星期二','星期三','星期四','星期五','星期六','星期日'],
	'xdata':['失信被执行人','最高法被执行人','催欠公告','网贷逾期信息','信贷中介查询信息','网络负面信息','不良信息'],
	'ydata':[
		[15, 13, 12, 13, 10,11, 11],
		[15,13, 12, 13, 10,11, 11],
		[12,15, 13,13, 10,11,11],
		[15, 13, 12, 13, 10,11, 11],
		[15, 13, 12, 13, 11,10,11],
		[15, 13, 10,12, 13,10, 11],
		[12, 13, 10,11, 11,15, 13]
	]
};

var bartotaldata = {
	'xdata':['失信被执行人','最高法被执行人','催欠公告','网贷逾期信息','信贷中介查询信息','网络负面信息','不良信息'],
	'ydata':[18203, 23489, 29034, 104970, 131744, 30230,30230]
		
};

var content = document.getElementById("content");

$(document).ready(function(){
	refresh();
});

$(window).on("resize",function(){
	piechart.resize();
	bartodaychart.resize();
	linechart.resize();
	bartotalchart.resize();
});

function refresh(){
	drawpie(piedata,'dataPieToday');
	drawbartoday(bartodaydata,'dataBarToday');
	drawline(linedata,'dataLineTotal');
	drawbartotal(bartotaldata,'dataBarTotal');
}

function drawpie(dataInfo,id){
	console.log("this is pie");
	piechart = echarts.init(document.getElementById(id));
	var option = {
			backgroundColor:'#fff',
			title:{
			        text: '今日新增数据占比'
			    },
			grid:{
				top:'5%',
				left:'10%',
				right:'5%',
				bottom:'10%'
			},
		    tooltip: {
		        trigger: 'item',
		        formatter: "{b}: {c} ({d}%)"
		    },
		    series: [
		        {
		            name:'数据类型占比',
		            type:'pie',
		            radius: ['40%', '60%'],
		            center:['45%','55%'],
		            avoidLabelOverlap: false,
		            label: {
		                normal: {
		                    show: true,
		                    position: 'outside'
		                },
		                emphasis: {
		                    show: true
		                }
		            },
		            labelLine: {
		                normal: {
		                    show: true
		                }
		            },
		            data:dataInfo.ydata
		        }
		    ]
		};
	piechart.setOption(option);
}

function drawbartoday(dataInfo,id){
	bartodaychart = echarts.init(document.getElementById(id));
	var option = {
				backgroundColor:'#fff',
			    title: {
			        text: '今日新增数据概况'
			    },
			    grid:{
					top:'20%',
					left:'5%',
					right:'5%',
					bottom:'20%'
				},
			    tooltip: {
			        trigger: 'axis'
			    },
			    legend: {
			        data:['数据数量','数据环比'],
			        top:'5%'
			    },
			    xAxis:  {
			        type: 'category',
			        data: dataInfo.xdata,
			        axisLabel:{
			        	interval:0,
			        	rotate:'-20'
			        }
			    },
			    yAxis: {
			        type: 'value'
			    },
			    series: [
			        {
			            name:'数据数量',
			            type:'bar',
			            data:dataInfo.ydata1
			        },
			        {
			            name:'数据环比',
			            type:'line',
			            data:dataInfo.ydata2		            
			        }
			    ]
			};
	bartodaychart.setOption(option);
}

function drawline(dataInfo,id){
	linechart = echarts.init(document.getElementById(id));
	var option = {
				backgroundColor:'#fff',
			    title: {
			        text: '数据一周增长概况'
			    },
			    grid:{
					top:'30%',
					left:'5%',
					right:'5%',
					bottom:'10%'
				},
			    tooltip: {
			        trigger: 'axis'
			    },
			    legend: {
			        data:dataInfo.xdata,
			        top:'10%'
			    },
			    xAxis:  {
			        type: 'category',
			        data: dataInfo.xdata1
			    },
			    yAxis: {
			        type: 'value'
			    },
			    series: [
			        {
			            name:dataInfo.xdata[0],
			            type:'line',
			            data:dataInfo.ydata[0]
			        },
			        {
			            name:dataInfo.xdata[1],
			            type:'line',
			            data:dataInfo.ydata[1]
			        },
			        {
			            name:dataInfo.xdata[2],
			            type:'line',
			            data:dataInfo.ydata[2]
			        },
			        {
			            name:dataInfo.xdata[3],
			            type:'line',
			            data:dataInfo.ydata[3]
			        },
			        {
			            name:dataInfo.xdata[4],
			            type:'line',
			            data:dataInfo.ydata[4]
			        },
			        {
			            name:dataInfo.xdata[5],
			            type:'line',
			            data:dataInfo.ydata[5]
			        },
			        {
			            name:dataInfo.xdata[6],
			            type:'line',
			            data:dataInfo.ydata[6]
			        }       
			    ]
			};
	linechart.setOption(option);
}

function drawbartotal(dataInfo,id){
	bartotalchart = echarts.init(document.getElementById(id));
	var option = {
			backgroundColor:'#fff',
		    title: {
		        text: '数据总量'
		    },
		    grid:{
					top:'20%',
					left:'18%',
					right:'5%',
					bottom:'10%'
				},
		    tooltip: {
		        trigger: 'axis',
		        axisPointer: {
		            type: 'shadow'
		        },
		        formatter:'{b}:{c}'
		    },
		    label:{
		    	normal:{
		    		show:true,
		    		position:'inside'
		    	},
		    	emphasis:{
		    		show:true
		    	}
		    },
		    xAxis: {
		        type: 'value'
		    },
		    yAxis: {
		        type: 'category',
		        data: dataInfo.xdata
		    },
		    series: [
		        {
		            name: '数据总量',
		            type: 'bar',
		            data: dataInfo.ydata  
		        }
		    ]
		};
	bartotalchart.setOption(option);
}