var linedata = {
	'xdata':['失信被执行人','最高法被执行人','催欠公告','网贷逾期信息','信贷中介查询信息','网络负面信息','不良信息'],
	'ydata':[
		[18203999, 23489999, 29034777, 104970777, 131744666, 30230555,30230333],
		[11000, 11222, 15333, 13111, 12234, 13345, 10111]
	]
};

window.onresize = function(){
	lineChart.resize();
}

drawLine(linedata,'chartBox');
fillTxt(linedata);
var content = document.getElementById("content");

/*函数部分*/
function drawLine(dataInfo,id){
	lineChart = echarts.init(document.getElementById(id));
	var option = {
			    title: {
			        text: '库存数据总量',
			        top:'5%',
			        left:'2%'
			    },
			    grid:{
					top:'30%',
					left:'7%',
					right:'3%',
					bottom:'12%'
				},
			    tooltip: {
			        trigger: 'axis'
			    },
			    legend: {
			        data:['数据总量','今日数据增量'],
			        top:'10%'
			    },
			    xAxis:  {
			        type: 'category',
			        boundaryGap:false,
			        axisLabel:{
			        	interval:0
			        },
			        data: dataInfo.xdata
			    },
			    yAxis: {
			        type: 'value'
			    },

			    series: [
			        {
			            name:'数据总量',
			            type:'line',
			            smooth:true, 
			            lineStyle:{
			            	normal:{
			            		color:'#9A999D'
			            	}
			            },
			            areaStyle:{
			            	normal:{
			            		show:true,
			            		color:'#282736'
			            	}
			            },
			            data:dataInfo.ydata[0],

			        },
			        {
			            name:'今日数据增量',
			            type:'line',
			            areaStyle:{
			            	normal:{
			            		show:true,
			            		color:'#282736'

			            	}
			            },
			            data:dataInfo.ydata[1]
			        } 
			    ]
			};
	lineChart.setOption(option);
}

//动态生成今日增量li里面的内容
function fillTxt(dataInfo){
	var todayData = document.getElementById("todayData");
	var lis = todayData.getElementsByTagName('li');
	var sumtoday=0,sumtotal=0;

	for(var i = 0; i<lis.length ; i++){
		var p = lis[i].getElementsByTagName('p')[0];
		var span = lis[i].getElementsByTagName('span')[0];
		p.innerHTML = dataInfo.xdata[i];
		span.innerHTML = numFormat(dataInfo.ydata[1][i]);

		//填写toptitle
		sumtoday+=parseInt(dataInfo.ydata[1][i]);
		sumtotal+=parseInt(dataInfo.ydata[0][i]);

	}
	$("#todayTitle>span").html(numFormat(sumtoday));
	$("#totalTitle>span").html(numFormat(sumtotal));

}

//浮世绘背景
drawliquid('liquidBackground');
function drawliquid(id){
	var waves = [{
	    value: 0.4,
	    valueSine: 0.1,
	    period: 15000,
	    amplitude: 120,
	    amplitudeSine: 100,
	    waveLength: '80%'
	}, {
	    value: 0.42,
	    valueSine: 0.05,
	    period: 14000,
	    amplitude: 100,
	    amplitudeSine: 10,
	    waveLength: '40%'
	}, {
	    value: 0.4,
	    valueSine: 0.05,
	    period: 11500,
	    amplitude: 50,
	    amplitudeSine: 10,
	    waveLength: '20%'
	}, {
	    value: 0.4,
	    valueSine: 0.05,
	    period: 13000,
	    amplitude: 70,
	    amplitudeSine: 10,
	    waveLength: '60%'
	}, {
	    value: 0.35,
	    valueSine: 0.05,
	    period: 12000,
	    amplitude: 60,
	    amplitudeSine: 10,
	    waveLength: '40%'
	}, {
	    value: 0.3,
	    valueSine: 0.05,
	    period: 14000,
	    amplitude: 15,
	    amplitudeSine: 10,
	    waveLength: '20%'
	}, {
	    value: 0.3,
	    valueSine: 0.05,
	    period: 11500,
	    amplitude: 60,
	    amplitudeSine: 10,
	    waveLength: '30%'
	}];

	var data = [];
	var phases = [0, 0.6, 0.8];
	var values = [1, 0.9, 0.85];
	for (var w = 0; w < waves.length; ++w) {
	    for (var i = 0; i < 3; ++i) {
	        data.push({
	            value: waves[w].value * values[i],
	            amplitude: waves[w].amplitude,
	            phase: phases[i] + w,
	            period: waves[w].period,
	            waveLength: waves[w].waveLength
	        });
	    }
	}

	var myChart = echarts.init(document.getElementById(id));
	option = {
	    backgroundColor: new echarts.graphic.LinearGradient(
	        0, 0, 0, 1, [{
	            offset: 0,
	            color: '#faf2cd'
	        }, {
	            offset: 0.4,
	            color: '#d2b083'
	        }, {
	            offset: 1,
	            color: '#a38d66'
	        }]
	    ),
	    series: [{
	        radius: '600%',
	        center:['50%','10%'],
	        color: ['#fdeec7', '#799fa2', '#282536'],
	        type: 'liquidFill',
	        data: data,
	        animationDurationUpdate: 100000,
	        animationEasingUpdate: 'cubicInOut',
	        progressive:200,
	        backgroundStyle: {
	            color: 'transparent'
	        },
	        outline: {
	            show: false
	        },
	        label: {
	            normal: {
	                textStyle: {
	                    color: '#282536',
	                    fontSize: 72
	                },
	                formatter: function() {
	                    return '';
	                }
	            }
	        }
	    }]
	};
	myChart.setOption(option);
}

//数字千分位函数
function numFormat(d){
	var numArr = d.toString().split("");
	var newStr;
	if(numArr.length%3!=0){
		var n = Math.floor(numArr.length/3);
	}else{
		var n = Math.floor(numArr.length/3)-1;
	}
	
	var m = numArr.length;
	for(var i=1;i<=n;i++){
		numArr.splice((m-(3*i)),0,"-");
	}
	newStr = numArr.join("");

	return newStr.replace(/-/g,",");
}
